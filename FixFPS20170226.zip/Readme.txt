FixFPS

Fix the frames to a more consistent pattern with the help of Matroska Version 2 Timecodes.  Mostly useful for fixing weird framerate from using a third party program to capture (ex. .kkapture with Mupen).  Generally used with the plugin ExactDedup.  It should be noted that FixFPS would try it's best not to lose any frames from the source.  It does this by pushing frames to the next available spot, if possible, but it can cause side effects.

Usage:

FixFPS(clip c, string times="times.txt", int frames=30000, int div=2, int mul=1)

Where:

c	The clip to use as the source
times	The path to  Matroska timecodes (v2)
frames	The output frame count
div	The divider of the original frame rate to align to
mul	The multiplier of the frame rate after the divide

Example:

Let's say you capture Super Mario 64 with .kkapture and Mupen.  You know the gameplay of Super Mario 64 is 30 FPS, but the intro Nintendo logo is 60 FPS.  Normally the capture from .kkapture is 120 FPS.  So the divider is 120 / 30 = 4 (to align to 30 FPS) and multiplier is 60 / 30 = 2 to output to 60 FPS.  Here is a possible script:

LoadPlugin("ExactDedup.dll")
LoadPlugin("FixFPS.dll")
AVISource("Mario64.avi")
trim(0, 5999) # You might want to align to the divider, so in this case a multiple of 4
ExactDedup(firstpass=false, dupinfo="Mario64 dups.txt")
FixFPS("Mario64 times.txt", 1500, 4, 2)

Changelog:


2016/02/26:
	- Initial release (real date was a few years ago)
