#include <stdio.h>
#include <bitset>
#include <deque>
#include <vector>

#include "windows.h"
#include "avisynth.h"

class FixFPS : public GenericVideoFilter {
public:
	FixFPS(PClip _child, const char* _times, unsigned int _frames, unsigned int _div, unsigned int _mul, IScriptEnvironment* env) : GenericVideoFilter(_child) {
		times = _times;
		frames = _frames;
		div = _div;
		mul = _mul;

		CalcMap(env);
	}
	~FixFPS() {
		if (file) {
			fclose(file);
			file = NULL;
		}
	}
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);

private:
	void CalcMap(IScriptEnvironment* env);

	const char* times;
	unsigned int frames;
	unsigned int div;
	unsigned int mul;

	FILE* file;

	std::unique_ptr<unsigned int[]> framemap;
};

void FixFPS::CalcMap(IScriptEnvironment* env) {
	std::deque<int> inTimes;

	if (fopen_s(&file, times, "r")) {
		env->ThrowError("FixFPS:  Failed to open times file for reading"); 
	}
	while (!feof(file)) {
		float i = 0;
		char* line = new char[100];
		if(fgets(line, 100, file) != NULL && line[0] != '#') {
			sscanf_s(line, "%f", &i);
			inTimes.push_back((int)(((double)i * ((double)vi.fps_numerator/(double)vi.fps_denominator) / (double)1000.0) + (double)0.5));
		}
	}
	fclose(file);

	std::unique_ptr<unsigned int[]> data(new unsigned int[frames]);
	for (unsigned int i = 0; i < frames; i++) {
		data[i] = 0;
	}

	// Place known spot times
	std::deque<int> undecidedTimes;
	while (!inTimes.empty()) {
		int conTime = inTimes.front();
		inTimes.pop_front();
		if (div % 2 == 0) {
			if (conTime % div < div / 2) { // go lower
				data[conTime / div]++;
			}
			else if (conTime % div > div / 2) { // go higher
				data[(conTime / div) + 1]++;
			}
			else { // undecided
				undecidedTimes.push_back(conTime);
			}
		}
		else {
			if (conTime % div <= div / 2) { // go lower
				data[conTime / div]++;
			}
			else { // go higher
				data[(conTime / div) + 1]++;
			}
		}
	}

	// Try to place undecided times in frames that have least conflict
	std::deque<int> tempUndecidedTimes;
	bool more = false;
	do {
		more = false;
		tempUndecidedTimes.clear();
		while (!undecidedTimes.empty()) {
			int conTime = undecidedTimes.front();
			undecidedTimes.pop_front();
			if (data[conTime / div] < data[(conTime / div) + 1]) {
				data[conTime / div]++;
				more = true;
			}
			else if (data[conTime / div] > data[(conTime / div) + 1]) {
				data[(conTime / div) + 1]++;
				more = true;
			}
			else {
				tempUndecidedTimes.push_back(conTime);
			}
		}
		undecidedTimes = tempUndecidedTimes;
	} while (more);

	// Try place times that are known to cause shift somewhere else
	int numAvoidShifted = 0; // Debug information
	tempUndecidedTimes.clear();
	while (!undecidedTimes.empty()) {
		int conTime = undecidedTimes.front();
		undecidedTimes.pop_front();
		if (data[conTime / div] >= mul) {
			int highCount = -1;
			int high = -1;
			for (unsigned int i = (conTime / div) + 2; i < frames; i++) {
				if (highCount == -1) {
					highCount = 1;
				}
				else {
					highCount++;
				}
				if (data[i] < mul) {
					high = i;
					break;
				}
			}
			int lowCount = -1;
			int low = -1;
			for (int i = (conTime / div) - 1; i > -1; i--) { // Do not make unsigned!
				if (lowCount == -1) {
					lowCount = 1;
				}
				else {
					lowCount++;
				}
				if (data[i] < mul) {
					low = i;
					break;
				}
			}
			if (lowCount <= highCount) {
				data[low]++;
				numAvoidShifted += lowCount;
			}
			else {
				data[high]++;
				numAvoidShifted += highCount;
			}
		}
		else {
			tempUndecidedTimes.push_back(conTime);
		}
	}
	undecidedTimes = tempUndecidedTimes;

	// Choose lower time since no idea where it goes
	int numUnd = 0;
	for (unsigned int i = 0; i < undecidedTimes.size(); i++) {
		int conTime = undecidedTimes.at(i);
		data[conTime / div]++;
		numUnd++;
	}

	// Shift times as needed
	int numShifted = 0; // Debug information
	for (unsigned int i = 0; i < frames; i++) {
		while (data[i] > mul) {
			int highCount = -1;
			int high = -1;
			for (unsigned int j = i + 1; j < frames; j++) {
				if (highCount == -1) {
					highCount = 1;
				}
				else {
					highCount++;
				}
				if (data[j] < mul) {
					high = j;
					break;
				}
			}
			int lowCount = -1;
			int low = -1;
			for (int j = i - 1; j > -1; j--) { // Do not make unsigned!
				if (lowCount == -1) {
					lowCount = 1;
				}
				else {
					lowCount++;
				}
				if (data[j] < mul) {
					low = j;
					break;
				}
			}
			if (lowCount <= highCount) {
				data[low]++;
				numShifted += lowCount;
			}
			else {
				data[high]++;
				numShifted += highCount;
			}
			data[i]--;
		}
	}

	// Try to minimize unused areas
	int numMin = 0;
	for (unsigned int i = 0; i < frames; i++) {
		if (data[i] > 1) {
			if (i != 0 && data[i - 1] == 0) {
				data[i]--;
				data[i - 1]++;
				numMin++;
			}
		}
	}
	for (unsigned int i = 0; i < frames; i++) {
		if (data[i] > 1) {
			if (i + 1 != frames && data[i + 1] == 0) {
				data[i]--;
				data[i + 1]++;
				numMin++;
			}
		}
	}

	// Expand the data
	int numAdded = 0; // Debug information
	std::unique_ptr<bool[]> dataExpand(new bool[frames * mul]);
	for (unsigned int i = 0; i < frames; i++) {
		if (data[i] == 0) {
			for (unsigned int j = 0; j < mul; j++) {
				dataExpand[(i * mul) + j] = false;
			}
		} else if (data[i] == 1) {
			dataExpand[(i * mul)] = true;
			numAdded++;
			for (unsigned int j = 1; j < mul; j++) {
				dataExpand[(i * mul) + j] = false;
			}
		} else {
			dataExpand[(i * mul)] = true;
			numAdded++;
			for (unsigned int j = 1; j < mul; j++) {
				dataExpand[(i * mul) + j] = false;
			}
			int factor = (int)(((double)mul / (double)data[i]) + 0.5);
			for (unsigned int j = 1; j < data[i]; j++) {
				dataExpand[(i * mul) + (j * factor)] = true;
				numAdded++;
			}
		}
	}

	// Make frame map
	framemap.reset(new unsigned int[frames * mul]);
	int lastFrame = 0, count = 1;
	for (unsigned int i = 0; i < (frames * mul); i++) {
		if(i != 0 && dataExpand[i]) {
			lastFrame++;
			count++;
		}
		framemap[i] = lastFrame;
	}

	vi.SetFPS(vi.fps_numerator * mul, vi.fps_denominator * div);
	vi.num_frames = (frames * mul);
}

PVideoFrame __stdcall FixFPS::GetFrame(int n, IScriptEnvironment* env) {
	return child->GetFrame(framemap[n], env);
}


AVSValue __cdecl Create_FixFPS(AVSValue args, void* user_data, IScriptEnvironment* env) {
	return new FixFPS(args[0].AsClip(), args[1].AsString("times.txt"), args[2].AsInt(0), args[3].AsInt(1), args[4].AsInt(1), env);
}


extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env) {
	env->AddFunction("FixFPS", "c[times]s[frames]i[div]i[mul]i", Create_FixFPS, 0);
	return 0;
}
